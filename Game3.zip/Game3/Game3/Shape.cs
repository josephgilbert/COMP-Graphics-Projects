﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Game3
{
    /*
    // Base Shape class that shapes are based off of.
    abstract class Shape
    {

        protected Vector3 position;
        protected Color color;
        protected Model model;
        

        public Shape(Model model)
        {
            
            this.model = model;
        }

        public abstract void SetPosition(Vector3 position);
        public abstract void RenderShape(Matrix world, Matrix view, Matrix projection);
     

    } */

    abstract class Shape
    {

        protected Vector3 position;
        public string modelName;
        public string textureName;
        public Model shapeModel;
        public Effect shapeEffect;

        public Shape(Vector3 initialPosition)
        {
            SetPosition(initialPosition);
        }


        public void SetPosition(Vector3 initialPosition)
        {
            position = initialPosition;
        }
        public abstract void RenderShape(Matrix world, Matrix view, Matrix projection);

    }
}
