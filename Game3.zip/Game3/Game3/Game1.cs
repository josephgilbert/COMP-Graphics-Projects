﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Game3
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        private Matrix view = Matrix.CreateLookAt(new Vector3(0, 0, 50), new Vector3(0, 0, 0), Vector3.UnitY);
        private Matrix projection = Matrix.CreatePerspectiveFieldOfView(MathHelper.ToRadians(45), 800f / 480f, 0.1f, 1000);
        private Vector3 cameraPosition = new Vector3(0, 0, 50);
        private Effect skyboxEffect;
        private TextureCube textureCube;
        private Model cubeModel;
        private Model sphereModel;
        
        private float pitch = 0.0f;
        private float yaw = 0.0f;

        private const float ANGLE_CHANGE = 0.05f;
        private const float DISTANCE_CHANGE = 0.5f;

        private BasicEffect ballEffect;
        private BasicEffect boxEffect;
        private SkyBox skybox;
        private Ball ball;
        private Gamebox gamebox;

        private Vector3 ballVelocity;
        private Color ballColor = new Color(100);

        private VertexBuffer vertexBuffer;
        private IndexBuffer indexBuffer;
        RasterizerState wireFrameState = new RasterizerState();
        RasterizerState nonWireFrameState;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.GraphicsProfile = GraphicsProfile.HiDef;

            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            ballVelocity = new Vector3(4, 4, 4);
            wireFrameState.FillMode = FillMode.WireFrame;
            wireFrameState.CullMode = CullMode.None;
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            
            spriteBatch = new SpriteBatch(GraphicsDevice);
            ballEffect = new BasicEffect(GraphicsDevice);
            boxEffect = new BasicEffect(GraphicsDevice);

            cubeModel = Content.Load<Model>("cube");
            sphereModel = Content.Load<Model>("sphere");
            skyboxEffect = Content.Load<Effect>("Skybox");
            textureCube = Content.Load<TextureCube>("Ocean");

            skybox = new SkyBox(cameraPosition, skyboxEffect, textureCube);
            skybox.shapeModel = cubeModel;
            skybox.SetPosition(cameraPosition);

            gamebox = new Gamebox(Vector3.Zero, ballEffect);
            gamebox.shapeModel = cubeModel;

            ball = new Ball(Vector3.Zero, ballVelocity, ballEffect, ballColor);
            ball.shapeModel = sphereModel;
            ball.SetPosition(Vector3.Zero);
            VertexPositionColor[] lineVertices = new VertexPositionColor[] {
            new VertexPositionColor(new Vector3(1, 1, 1), Color.White), //Upper right 0
            new VertexPositionColor(new Vector3(1, -1, 1), Color.White), //lower right 1
            new VertexPositionColor(new Vector3(-1, -1, 1), Color.White), //lower left 2
            new VertexPositionColor(new Vector3(-1, 1, 1), Color.White), //upper left 3
             
            new VertexPositionColor(new Vector3(1, 1, -1), Color.White), //Upper right 4
            new VertexPositionColor(new Vector3(1, -1, -1), Color.White), //lower right 5 
            new VertexPositionColor(new Vector3(-1, -1, -1), Color.White), //lower left 6 
            new VertexPositionColor(new Vector3(-1, 1, -1), Color.White), //upper left 7
            };
            vertexBuffer = new VertexBuffer(GraphicsDevice, typeof(VertexPositionColor), 8, BufferUsage.WriteOnly);
            vertexBuffer.SetData<VertexPositionColor>(lineVertices);
            short[] lineShorts = new short[24] {
                0, 1, 
                1, 2,
                2, 3,
                3, 0,

                4, 5,
                5, 6,
                6, 7,
                7, 4,

                0, 4,
                1, 5,
                2, 6,
                3, 7

            };

            indexBuffer = new IndexBuffer(GraphicsDevice, IndexElementSize.SixteenBits, 24, BufferUsage.WriteOnly);
            indexBuffer.SetData<short>(lineShorts);
            /*
            GraphicsDevice.SetVertexBuffer(vertexBuffer);
            GraphicsDevice.RasterizerState = RasterizerState.CullNone;
            foreach (EffectPass pass in effect.CurrentTechnique.Passes)
            {
                pass.Apply();
                GraphicsDevice.DrawPrimitives(PrimitiveType.TriangleList, 0, 12);
            }
            */
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            Vector3 forward = new Vector3(0, 0, -1);
            Vector3 right = new Vector3(1, 0, 0);
            Vector3 up = new Vector3(0, 1, 0);

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            if (Keyboard.GetState().IsKeyDown(Keys.Up))
                // Rotate camera clockwise around X axis
                pitch += ANGLE_CHANGE;

            if (Keyboard.GetState().IsKeyDown(Keys.Left))
                // Rotate the forward direction counterclockwise around Y axis
                yaw += ANGLE_CHANGE;

            if (Keyboard.GetState().IsKeyDown(Keys.Down))
                // Rotate camera counterclockwise around X axis
                pitch -= ANGLE_CHANGE;

            if (Keyboard.GetState().IsKeyDown(Keys.Right))
                // Rotate camera clockwise around Y axis
                yaw -= ANGLE_CHANGE;

            Matrix rotation = Matrix.CreateFromYawPitchRoll(yaw, pitch, 0);
            forward = Vector3.Transform(forward, rotation);
            right = Vector3.Transform(right, rotation);
            up = Vector3.Transform(up, rotation);

            if (Keyboard.GetState().IsKeyDown(Keys.W))
                // Move camera forward
                cameraPosition += forward * DISTANCE_CHANGE;

            if (Keyboard.GetState().IsKeyDown(Keys.A))
                // Move camera left
                cameraPosition -= right * DISTANCE_CHANGE;

            if (Keyboard.GetState().IsKeyDown(Keys.S))
                // Move camera backward
                cameraPosition -= forward * DISTANCE_CHANGE;

            if (Keyboard.GetState().IsKeyDown(Keys.D))
                // Move camera right
                cameraPosition += right * DISTANCE_CHANGE;

            view = Matrix.CreateLookAt(cameraPosition, cameraPosition + forward, up);


            // TODO: Add your update logic here
            skybox.SetPosition(cameraPosition);
            ball.UpdatePosition(gameTime.ElapsedGameTime.Milliseconds/1000.0f);
            base.Update(gameTime);
            
        }



        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);


            GraphicsDevice.RasterizerState = RasterizerState.CullClockwise;
            skybox.RenderShape(Matrix.CreateScale(100) * Matrix.CreateTranslation(cameraPosition), view, projection);
            
            GraphicsDevice.RasterizerState = RasterizerState.CullCounterClockwise;
            ball.RenderShape(Matrix.CreateScale(1 / 3f) * Matrix.CreateTranslation(ball.GetPosition()), view, projection);

            GraphicsDevice.SetVertexBuffer(vertexBuffer);
            GraphicsDevice.Indices = indexBuffer;
            GraphicsDevice.RasterizerState = RasterizerState.CullNone;
            boxEffect.LightingEnabled = false;
            boxEffect.VertexColorEnabled = true;
            boxEffect.World = Matrix.CreateScale(10, 10, 20);
            boxEffect.View = view;
            boxEffect.Projection = projection;
            foreach (EffectPass pass in boxEffect.CurrentTechnique.Passes)
            {
                pass.Apply();
                GraphicsDevice.DrawIndexedPrimitives(PrimitiveType.LineList, 0, 0, 12);
            }
            //gamebox.RenderShape(Matrix.CreateScale(10), view, projection);
            //GraphicsDevice.RasterizerState = nonWireFrameState;
            GraphicsDevice.DrawPrimitives(PrimitiveType.LineList, 0, 12);
            base.Draw(gameTime);
        }
    }
}
