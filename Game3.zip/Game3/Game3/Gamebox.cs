﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game3
{
    class Gamebox : Cube
    {
        protected BasicEffect effect;
        public Gamebox(Vector3 initialPosition, BasicEffect effect) : base(initialPosition)
        {
            this.effect = effect;
        }

        public override void RenderShape(Matrix world, Matrix view, Matrix projection)
        {
            foreach (ModelMesh mesh in shapeModel.Meshes)
            {
                foreach (ModelMeshPart part in mesh.MeshParts)
                {
                    part.Effect = effect;
                    effect.World = world;
                    effect.View = view;
                    effect.Projection = projection;
                    effect.EnableDefaultLighting();
                    effect.EmissiveColor = Color.White.ToVector3();
                    effect.SpecularColor = new Vector3(0.0f);

                }
                mesh.Draw();
            }
        }


    }
}
