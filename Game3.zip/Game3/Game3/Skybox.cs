﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game3
{
    
    class SkyBox : Cube
    {
        protected TextureCube textureCube;

        public SkyBox(Vector3 initialPosition, Effect effect, TextureCube textureCube) : base(initialPosition)
        {
            shapeEffect = effect;
            this.textureCube = textureCube;
        }


        public override void RenderShape(Matrix world, Matrix view, Matrix projection)
        {   
            
            foreach (ModelMesh mesh in shapeModel.Meshes)
            {
                foreach (ModelMeshPart part in mesh.MeshParts)
                {
                    part.Effect = shapeEffect;
                    shapeEffect.Parameters["World"].SetValue(mesh.ParentBone.Transform * world);
                    shapeEffect.Parameters["View"].SetValue(view);
                    shapeEffect.Parameters["Projection"].SetValue(projection);
                    shapeEffect.Parameters["Camera"].SetValue(position);
                    shapeEffect.Parameters["SkyBoxTexture"].SetValue(textureCube);
                }
                mesh.Draw();
            }
        }
    }
}
