﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game3
{
    class Cube : Shape
    {
        public Cube(Vector3 initialPosition) : base(initialPosition)
        {
            modelName = "cube";
        }

        public override void RenderShape(Matrix world, Matrix view, Matrix projection)
        {
            //foreach (ModelMesh mesh in shapeModel.Meshes)
            //{
            //    foreach (Effect effect in mesh.Effects)
            //    {

            //    }

            //}
        }
    }
}
