﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game3
{
    /*
    class Ball : Shape
    {
        protected Vector3 velocity;
        protected BasicEffect effect;
        public Ball(Model model, Vector3 velocity, BasicEffect effect, Color color) : base(model)
        {
            this.color = color;
            this.effect = effect;
            this.velocity = velocity;
        }

        public override void RenderShape(Matrix world, Matrix view, Matrix projection)
        {
            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (ModelMeshPart part in mesh.MeshParts)
                {
                    part.Effect = effect;
                    effect.World = world;
                    effect.View = view;
                    effect.Projection = projection;
                    effect.EnableDefaultLighting();
                    effect.EmissiveColor = color.ToVector3();
                    effect.SpecularColor = new Vector3(0.0f);
                }
                mesh.Draw();
            }
        }

        public void SetVelocity(Vector3 velocity)
        {
            this.velocity = velocity;
        }

        public override void SetPosition(Vector3 position)
        {
            this.position = position;
        }

        public Vector3 GetPosition()
        {
            return position;
        }

        public void UpdatePosition(float time)
        {
            position += velocity * time;
        }

        
    } */

    class Ball : Collidable
    {
        protected Vector3 Velocity;
        protected Color color;
        protected BasicEffect effect;
        public Ball(Vector3 initialPosition, Vector3 initialVelocity, BasicEffect effect, Color color) : base(initialPosition)
        {
            modelName = "sphere";
            Velocity = initialVelocity;
            this.color = color;
            this.effect = effect;
        }

        public void setVelocity(Vector3 v)
        {
            Velocity = v;
        }

        public void UpdatePosition(float time)
        {
            position += Velocity * time;
        }

        public Vector3 GetPosition()
        {
            return position;
        }

        public override void RenderShape(Matrix world, Matrix view, Matrix projection)
        {
            foreach (ModelMesh mesh in shapeModel.Meshes)
            {
                foreach (ModelMeshPart part in mesh.MeshParts)
                {
                    part.Effect = effect;
                    effect.World = world;
                    effect.View = view;
                    effect.Projection = projection;
                    effect.EnableDefaultLighting();
                    effect.EmissiveColor = color.ToVector3();
                    effect.SpecularColor = new Vector3(0.0f);
                }
                mesh.Draw();
            }
        }

    }
}
