﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game3
{
    abstract class Collidable : Shape
    {
        public Collidable(Vector3 initialPosition) : base(initialPosition) { }
        public Vector3 Collision(Collidable obj)
        {
            //IMPLEMENT COLLISION PHYSICS HERE!
            return Vector3.Zero;
        }
    }
}
